# Walless

* React 16
* Webpack 4
* Babel
* Staging ES Next Features
* Hot Module Replacement
